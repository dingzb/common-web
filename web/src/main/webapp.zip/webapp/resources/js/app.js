/**
 * main app
 */

angular.module('ws.app', [
    'ws.basic',
    'ws.permission',
    'ws.menus',
    'ws.login',
    'ws.datagrid',
    'ui.router',
    'ngGrid',
    'ngMessages',
    'ui.bootstrap',
    'ui.tree',
    'ngFileUpload']).run(['$rootScope', function ($rootScope) {

    /**
     * 全局提示框
     * @param  String message [提示消息内容]
     * @param  [String|Boolean] title   [提示消息表头，
     *   如果省略则使用默认，如果给true则表示提示信息]
     * @param [backFun]    [点击确定回调函数]
     * @param [funParam]    [回调函数参数，当参数只有一个时可以直接是参数，
     *        当参数是多个时，可以传入一个数组，具体实现在自己回调函数中取]
     */
    $rootScope.showMsg = function (message, title, backFun, funParam) {
        var showBtn = false;
        var titleStr = "错误提示";

        if (typeof title == "string")
            titleStr = title;
        if (typeof title == "boolean" && title == true)
            titleStr = "提示信息";
        if (typeof title == "boolean" && title == false)
            titleStr = "错误提示";
        if (typeof backFun == "function") {
            showBtn = true;
            titleStr = "确认信息";
            $rootScope.closeModal = function () {
                $("#GMODALCONFIRM").modal('hide');
                if (!$rootScope.$$phase) {
                    $rootScope.$apply(backFun, funParam);
                } else {
                    backFun.call(this, funParam);
                }
            };
        } else {
            /*防止上一次遗留的fun*/
            $rootScope.closeModal = function () {
                $("#GMODALCONFIRM").modal('hide');
            }
        }

        if ($rootScope.$$phase != null) {
            $rootScope.gmodal = {
                title: titleStr,
                message: message,
                showBtn: showBtn,
                showAlert: !showBtn
            }
        } else {
            $rootScope.$apply(function () {
                $rootScope.gmodal = {
                    title: titleStr,
                    message: message,
                    showBtn: showBtn,
                    showAlert: !showBtn
                }
            });
        }
        if ($("#GMODALCONFIRM").length == 0) {
            alert(message);
        } else {
            $("#GMODALCONFIRM").modal('show');
        }
    };

    $rootScope.closeModal = function () {
        $("#GMODALCONFIRM").modal('hide');
    };

    // /**
    //  * 全局遮罩层
    //  * @param  {Boolean} isShow  [是否展示遮罩层]
    //  * @param  {[number|string]}  message [提示信息]
    //  * @return {[null]}          [null]
    //  */
    // $rootScope.mask = function (isShow, message) {
    //     var msg = "";
    //     if (isShow) {
    //         if (message == 0) {
    //             msg = "正在保存...";
    //         } else if (message == 1) {
    //             msg = "正在删除...";
    //         } else if (message == 2) {
    //             msg = "正在编辑...";
    //         } else if (message == 3) {
    //             msg = "正在查询...";
    //         } else {
    //             msg = message;
    //         }
    //         $rootScope.mask = {
    //             show: true,
    //             content: msg
    //         }
    //     } else {
    //         $rootScope.mask = {
    //             show: false,
    //             content: msg
    //         }
    //     }
    // }
}])
//全局$http.post配置
    .config(['$httpProvider', function ($httpProvider) {
        $httpProvider.defaults.headers.post['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8';
        $httpProvider.defaults.transformRequest = function (data) {
            if (data === undefined)
                return data;
            return $.param(data);
        }
    }])

    /**
     * state变化时激活变化的state菜单
     */
    .run(['$rootScope', '$state', 'activeServ', function ($rootScope, $state, activeServ) {
        $rootScope.$on('$stateChangeStart', function (evt, toState, toParams, fromState, fromParams) {
            angular.state = {
                current: toState.name
            };
            activeServ.active(toState.name);
        });
        $rootScope.$on('ngRepeatFinished', function (evt, type) {
            activeServ.active(angular.state.current, type);
        });
    }])
    /**
     * 渲染完后执行指令
     */
    .directive('wsOnFinishRenderFilters', function ($timeout) {
        return {
            restrict: 'A',
            link: function (scope, element, attr) {
                if (scope.$last === true) {
                    $timeout(function () {
                        scope.$emit('ngRepeatFinished', attr.activeType);
                    });
                }
            }
        };
    })
    /**
     * 替换<pre>.</pre>为<pre>-</pre>
     * 用在state名称指定ID时
     */
    .filter('period2minus', [function () {
        return function (text) {
            return text.replace(/\./g, '-');
        };
    }])

    /**
     * 截取字符长度
     * max:要保留的最大长度
     * tail：后缀
     *
     * */
    .filter('cut', function () {
        return function (value, max, tail) {
            if (!value) return '';

            max = parseInt(max, 10);
            if (!max) return value;
            if (value.length <= max) return value;

            value = value.substr(0, max);
            return value + (tail || ' …');
        };
    })

    /**
     * 唯一性 表单验证指令
     * usage:<input ws-unique="url?arg"/>
     * arg为后台接收参数名称
     * [input].uniqueAajax展示ajax进度
     */
    .directive('wsUnique', ['$q', '$http', function ($q, $http) {
        return {
            require: 'ngModel',
            scope: {
                wsUnique: '@'
            },
            link: function (scope, elm, attrs, ctrl) {
                var urls = scope.wsUnique.split('?');
                var def = null;
                var outterModel = null;
                var outterView = null;
                ctrl.$asyncValidators.unique = function (modelValue, viewValue) {
                    outterModel = modelValue;
                    outterView = viewValue;
                    if (ctrl.$isEmpty(modelValue)) {
                        return $q.when();
                    }
                    def = $q.defer();
                    return def.promise;
                };

                elm.on('blur', function () {
                    var data = {};
                    data[urls[1]] = outterModel;
                    if (!ctrl.$invalid) {
                        ctrl.uniqueAajax = true;
                        $http({
                            method: 'post',
                            url: urls[0],
                            data: data
                        }).success(function (data, status, headers, config) {
                            ctrl.uniqueAajax = false;
                            if (data.success) {
                                return data.data ? def.reject() : def.resolve();
                            } else {
                                return def.reject();
                            }
                        }).error(function () {
                            ctrl.uniqueAajax = false;
                            return def.reject();
                        });
                    } else {
                        return def.reject();
                    }
                });
            }
        };
    }])
    /**
     * form 比较指令
     * 参考http://docs.ngnice.com/guide/forms
     * <any ws-comparewith="the obj to compared"></any>
     */
    .directive('wsComparewith', [function () {
        return {
            require: 'ngModel',
            scope: {
                wsComparewith: '='
            },
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    if (viewValue == '' || viewValue == scope.wsComparewith) {
                        ctrl.$setValidity('wsComparewith', true);
                    } else {
                        ctrl.$setValidity('wsComparewith', false);
                    }
                    return viewValue;
                });
            }
        };
    }])
    .directive('wsDiffrentwith', [function () {
        return {
            require: 'ngModel',
            scope: {
                wsDiffrentwith: '='
            },
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    if (viewValue != '' && viewValue != scope.wsDiffrentwith) {
                        ctrl.$setValidity('wsDiffrentwith', true);
                    } else {
                        ctrl.$setValidity('wsDiffrentwith', false);
                    }
                    return viewValue;
                });
            }
        };
    }])
    .directive('wsDiffrentip', [function () {
        return {
            require: 'ngModel',
            scope: {
                wsDiffrentip: '='
            },
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    var IP_REGEXP = /^(([1-9]|([1-9]\d)|(1\d\d)|(2([0-4]\d|5[0-5])))\.)(([1-9]|([1-9]\d)|(1\d\d)|(2([0-4]\d|5[0-5])))\.){2}([1-9]|([1-9]\d)|(1\d\d)|(2([0-4]\d|5[0-5])))$/;
                    if (IP_REGEXP.test(viewValue) && IP_REGEXP.test(scope.wsDiffrentip)) {
                        var sourceIp = scope.wsDiffrentip;
                        var target = viewValue;
                        // var spoint=sourceIp.substring(sourceIp.lastIndexOf("."));
                        // var tpoint=target.substring(target.lastIndexOf("."));
                        // if(spoint!='.1'||tpoint!='.1'){
                        // 		ctrl.$setValidity('wsDiffrentip', false);
                        // 		return viewValue;
                        // }
                        sourceIp = sourceIp.substring(0, sourceIp.lastIndexOf("."));
                        target = target.substring(0, target.lastIndexOf("."));
                        if (target != '' && target != sourceIp) {
                            ctrl.$setValidity('wsDiffrentip', true);
                        } else {
                            ctrl.$setValidity('wsDiffrentip', false);
                            return undefined;
                        }
                    } else {
                        // 验证不通过 表示格式不正确
                        ctrl.$setValidity('wsDiffrentip', false);
                        return undefined;
                    }
                    return viewValue;
                });
            }
        };
    }])
    .directive('wsBiggerthan', [function () {
        return {
            require: 'ngModel',
            scope: {
                wsBiggerthan: '='
            },
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    var source = parseInt(viewValue, 10);
                    var target = scope.wsBiggerthan;
                    if (source != '' && source > target) {
                        ctrl.$setValidity('wsBiggerthan', true);
                    } else {
                        ctrl.$setValidity('wsBiggerthan', false);
                    }
                    return viewValue;
                });
            }
        };
    }])
    .directive('wsLessthan', [function () {
        return {
            require: 'ngModel',
            scope: {
                wsLessthan: '='
            },
            link: function (scope, elm, attrs, ctrl) {
                ctrl.$parsers.unshift(function (viewValue) {
                    var source = parseInt(viewValue, 10);
                    var target = scope.wsLessthan;
                    if (source != '' && source < target) {
                        ctrl.$setValidity('wsLessthan', true);
                    } else {
                        ctrl.$setValidity('wsLessthan', false);
                    }
                    return viewValue;
                });
            }
        };
    }])

    //配置子系统的state
    .config(['$stateProvider', function ($stateProvider) {
        $stateProvider
        //登录视图布局
            .state('login', {
                url: '/login',
                templateUrl: 'tpls/login.html'
            })
            //主视图布局
            .state('main', {
                url: '',
                views: {
                    '': {
                        templateUrl: 'tpls/main.html'
                    },
                    'top@main': {
                        templateUrl: 'tpls/common/navbar.html'
                    },
                    'bottom@main': {
                        templateUrl: 'tpls/welcome.html'
                    }
                }
            })
            .state('main.welcome', {
                url: '/'
            });
    }]);

/**
 * 初始启动配置
 *
 * 获取权限路径服务，并手动启动主网站主模块主App
 * @require angularjs 1.2.16
 * @require jquery 1.9.1
 */
(function ($, angular, document) {
    $(document).ready(function () {
        $.ajax({
            url: 'app/authorization',
            type: "POST",
            dataType: 'json',
            success: function (data) {
                angular.module('ws.app').run(['$rootScope', 'authorizationServ', function ($rootScope, authorizationServ) {
                    if (data.success) {
                        authorizationServ.set(data.data);
                    } else {
                        authorizationServ.init();
                    }
                }]);
                /////自定义对象
                angular.custom = {};
                angular.bootstrap(document, ['ws.app']);
            },
            statusCode: {
                401: function () {
                    location.href = '401';
                },
                404: function () {
                    location.href = '404';
                }
            }
        });
    });
})(jQuery, angular, document);