/**
 * 系统首页
 */
angular.module('ws.app')
    .controller('welcomeCtrl', function ($scope, $rootScope, $http, $location, $timeout) {

        $scope.goRedirectUrl = function (type) {
            var url = "";
            if (type === 'ap') {
                url = "/manage/control/ap";
            } else if (type === "onoffline") {
                url = "/authroization/authList/authMessage";
            } else if (type === "place") {
                url = "/manage/control/place";
            } else if (type === "warning") {
                url = "/manage/status/apalarm";
            } else if (type === "terminal") {
                url = "/manage/control/apTerminal";
            }
            // 

            //.search({})
            $location.path(url);
        };

        $scope.initCount = function () {
            $http({
                url: 'app/ac/apmanage/getApTips',
                method: 'get',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $scope.Aptip = data.data;
                } else {
                    $scope.Aptip = {
                        inLine: 0,
                        apSum: 0
                    }
                }
            });

            $http({
                url: 'app/analysis/system/place/getPlaceTips',
                method: 'get',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $scope.placeTip = data.data;
                } else {
                    $scope.placeTip = {
                        inService: 0,
                        placeSum: 0
                    }
                }
            });
            $http({
                url: 'app/welcome/getAuthorCount',
                method: 'get',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $scope.visitCount = data.data;
                } else {
                    $scope.visitCount = {
                        day: 0,
                        week: 0
                    }
                }
            });
            $http({
                url: 'app/welcome/getApalarmCount',
                method: 'get',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $scope.apalarmCount = data.data;
                } else {
                    $scope.apalarmCount = {
                        day: 0,
                        week: 0
                    }
                }
            });

            $http({
                url: 'app/welcome/getTerminalCount',
                method: 'get',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $scope.TerminalCount = data.data;
                } else {
                    $scope.TerminalCount = {
                        inLine: 0,
                        apSum: 0
                    }
                }
            });
        };

        $scope.initHistory = function () {
            $http({
                url: 'app/welcome/getVisitHistory',
                params: {type: 'month'},
                method: 'post',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $('#container').highcharts({
                        title: {
                            text: '上网人数统计',
                            x: -20 //center
                        },
                        xAxis: {
                            categories: data.data.category
                        },
                        yAxis: {
                            title: {
                                text: '上网人数 (个)'
                            },
                            plotLines: [{
                                value: 0,
                                width: 1,
                                color: '#808080'
                            }]
                        },
                        tooltip: {
                            valueSuffix: '个'
                        },
                        credits: {
                            enabled: false //版权
                        },
                        legend: {
                            enabled: false //设置显示图例
                        },
                        exporting: {
                            enabled: false
                        },
                        series: [{
                            name: '上网人数',
                            data: data.data.data
                        }]
                    });
                }
            });

        }

        $scope.initTypeScale = function () {
            $http({
                url: 'app/welcome/getVisitTypeScale',
                params: {type: 'month'},
                method: 'post',
                data: {}
            }).success(function (data) {
                if (data.success) {
                    $('#container2').highcharts({
                        chart: {
                            type: 'pie',
                            options3d: {
                                enabled: true,
                                alpha: 45,
                                beta: 0
                            }
                        },
                        credits: {
                            enabled: false //版权
                        },
                        exporting: {
                            enabled: false
                        },
                        title: {
                            text: '认证比例'
                        },
                        tooltip: {
                            pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
                        },
                        plotOptions: {
                            pie: {
                                allowPointSelect: true,
                                cursor: 'pointer',
                                depth: 35,
                                dataLabels: {
                                    enabled: true,
                                    format: '{point.name}'
                                }
                            }
                        },
                        series: [{
                            type: 'pie',
                            name: '认证占比',
                            data: data.data
                        }]
                    });
                }
            });
        }
    });
